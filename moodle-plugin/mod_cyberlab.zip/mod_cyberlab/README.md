# CyberLab Activity Module for Moodle

A Moodle activity module that enables teachers to add interactive cybersecurity labs to their courses. Students launch vulnerable target VMs and practice attacking them from their LynkBox (browser-based Kali Linux) environment.

## Features

- **Course Integration**: Add labs as activities within any Moodle course
- **Lab Templates**: Choose from pre-configured vulnerable VM templates (DVWA, Juice Shop, Metasploitable, etc.)
- **Session Management**: Automatic VM provisioning, status tracking, and cleanup
- **Difficulty Levels**: Beginner, Intermediate, Advanced, Expert
- **Connection Methods**: LynkBox (browser), Tailscale VPN, OpenVPN
- **CTF Support**: Flag submission and validation for capture-the-flag style labs
- **Progress Tracking**: Session history, completion tracking, time limits
- **Reports**: Teacher dashboard for monitoring student progress

## Requirements

- Moodle 4.4 or later
- `local_attackbox` plugin installed and configured
- CyberLab API infrastructure deployed

## Installation

1. Extract to `/mod/cyberlab/` in your Moodle installation
2. Visit Site Administration → Notifications to trigger the database upgrade
3. Purge caches: `php admin/cli/purge_caches.php`

## Configuration

This module inherits API configuration from `local_attackbox`:

- **API URL**: Set in Local plugins → AttackBox → API URL
- **Webhook Secret**: Set in Local plugins → AttackBox → Webhook Secret

## Usage

### For Teachers

1. Navigate to your course and turn on editing mode
2. Click "Add an activity or resource"
3. Select "CyberLab"
4. Configure the lab:
   - Choose a lab template
   - Set difficulty level
   - Define session duration
   - Select connection methods
   - Add objectives and hints
   - (Optional) Set expected flags for CTF validation

### For Students

1. Open the CyberLab activity in your course
2. Click "Start Lab" to launch the target VM
3. Wait for the lab to initialize (30-60 seconds)
4. Note the Target IP displayed
5. Click "Open LynkBox" to launch your attack environment
6. Attack the target at the displayed IP address
7. Click "Terminate Lab" when finished

## File Structure

```
mod_cyberlab/
├── version.php              # Plugin version and dependencies
├── lib.php                  # Core Moodle module functions
├── mod_form.php             # Activity settings form
├── view.php                 # Student view (lab launcher)
├── index.php                # Course labs listing
├── styles.css               # Module styles
├── amd/src/
│   └── lab_launcher.js      # Frontend JavaScript
├── classes/
│   ├── event/               # Event classes
│   └── external/            # AJAX services
├── db/
│   ├── install.xml          # Database schema
│   ├── access.php           # Capability definitions
│   └── services.php         # External services
└── lang/en/
    └── cyberlab.php         # Language strings
```

## Database Tables

- `cyberlab`: Activity instances
- `cyberlab_sessions`: Student session tracking
- `cyberlab_flags`: Flag submission records

## API Endpoints

The module communicates with the CyberLab orchestrator API:

- `POST /lab/create`: Start a new lab session
- `GET /lab/status/{session_id}`: Check session status
- `POST /lab/terminate`: End a lab session
- `GET /lab/templates`: List available templates

## Capabilities

| Capability                       | Description                 | Default Roles    |
| -------------------------------- | --------------------------- | ---------------- |
| `mod/cyberlab:view`              | View the activity           | Student, Teacher |
| `mod/cyberlab:attempt`           | Start lab sessions          | Student, Teacher |
| `mod/cyberlab:submitflags`       | Submit flags                | Student, Teacher |
| `mod/cyberlab:viewreports`       | View all students' progress | Teacher          |
| `mod/cyberlab:manage`            | Edit activity settings      | Editing Teacher  |
| `mod/cyberlab:terminatesessions` | End any student's session   | Teacher          |
| `mod/cyberlab:addinstance`       | Add new CyberLab            | Editing Teacher  |

## Development

### Building JavaScript

```bash
npx grunt amd --plugin=mod_cyberlab
```

### Testing

```bash
php admin/tool/phpunit/cli/init.php
vendor/bin/phpunit --testsuite mod_cyberlab_testsuite
```

## Version History

- **2026020400**: Initial release with core functionality

## License

GNU GPL v3 or later

## Support

For issues related to:

- This plugin: Create an issue in the CyberLab Infrastructure repository
- Moodle: https://moodle.org/support

# Building AMD Modules for local_attackbox

The JavaScript files in `amd/src/` need to be compiled to `amd/build/` for production use.

## Prerequisites

From your **Moodle installation directory** (not this plugin):

```bash
# Install Node.js dependencies (one-time)
npm install
```

## Building the minified files

### Option 1: From Moodle root directory

```bash
# Navigate to your Moodle installation
cd /path/to/moodle

# Build all AMD modules for this plugin
grunt amd --root=local/attackbox

# Or build all plugins
grunt amd
```

### Option 2: Using npx (if grunt not installed globally)

```bash
cd /path/to/moodle
npx grunt amd --root=local/attackbox
```

## Development Mode

If you're developing, you can skip building by enabling **cachejs** debugging in Moodle:

1. Go to **Site administration → Development → Debugging**
2. Set **Cache JavaScript** to **No**

This tells Moodle to use the source files directly from `amd/src/` instead of the minified versions in `amd/build/`.

## Files that need building

After any changes to these source files, rebuild:

- `amd/src/launcher.js` → `amd/build/launcher.min.js`
- `amd/src/lab-view.js` → `amd/build/lab-view.min.js`
- `amd/src/usage-dashboard.js` → `amd/build/usage-dashboard.min.js`
- `amd/src/admin-dashboard.js` → `amd/build/admin-dashboard.min.js`

## Quick Development Workaround

If you can't run grunt, you can temporarily copy the source file as the minified version:

```bash
cp amd/src/launcher.js amd/build/launcher.min.js
cp amd/src/lab-view.js amd/build/lab-view.min.js
```

Note: This won't be minified but will work. Rebuild properly before production deployment.

"""
LTI 1.3 utilities for CyberLab Orchestrator.

Handles JWT validation, OIDC authentication flow, and LTI message processing.
Supports LTI 1.3 Core and Deep Linking.
"""

import base64
import hashlib
import hmac
import json
import logging
import os
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlencode, urlparse

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# LTI 1.3 Constants
LTI_VERSION = "1.3.0"
LTI_MESSAGE_TYPE = "LtiResourceLinkRequest"
LTI_DEEP_LINKING_MESSAGE_TYPE = "LtiDeepLinkingRequest"

# LTI Claims (namespaced as per spec)
CLAIM_MESSAGE_TYPE = "https://purl.imsglobal.org/spec/lti/claim/message_type"
CLAIM_VERSION = "https://purl.imsglobal.org/spec/lti/claim/version"
CLAIM_DEPLOYMENT_ID = "https://purl.imsglobal.org/spec/lti/claim/deployment_id"
CLAIM_TARGET_LINK_URI = "https://purl.imsglobal.org/spec/lti/claim/target_link_uri"
CLAIM_RESOURCE_LINK = "https://purl.imsglobal.org/spec/lti/claim/resource_link"
CLAIM_ROLES = "https://purl.imsglobal.org/spec/lti/claim/roles"
CLAIM_CONTEXT = "https://purl.imsglobal.org/spec/lti/claim/context"
CLAIM_LAUNCH_PRESENTATION = "https://purl.imsglobal.org/spec/lti/claim/launch_presentation"
CLAIM_CUSTOM = "https://purl.imsglobal.org/spec/lti/claim/custom"
CLAIM_DEEP_LINKING_SETTINGS = "https://purl.imsglobal.org/spec/lti-dl/claim/deep_linking_settings"

# Standard OIDC/JWT Claims
CLAIM_ISS = "iss"
CLAIM_SUB = "sub"
CLAIM_AUD = "aud"
CLAIM_EXP = "exp"
CLAIM_IAT = "iat"
CLAIM_NONCE = "nonce"
CLAIM_AZP = "azp"
CLAIM_NAME = "name"
CLAIM_GIVEN_NAME = "given_name"
CLAIM_FAMILY_NAME = "family_name"
CLAIM_EMAIL = "email"
CLAIM_PICTURE = "picture"

# LTI Roles
ROLE_INSTRUCTOR = "http://purl.imsglobal.org/vocab/lis/v2/membership#Instructor"
ROLE_LEARNER = "http://purl.imsglobal.org/vocab/lis/v2/membership#Learner"
ROLE_ADMIN = "http://purl.imsglobal.org/vocab/lis/v2/membership#Administrator"
ROLE_MENTOR = "http://purl.imsglobal.org/vocab/lis/v2/membership#Mentor"


class LTIPlatformConfig:
    """Configuration for an LTI Platform (e.g., Moodle)."""
    
    def __init__(
        self,
        platform_id: str,
        client_id: str,
        deployment_id: str,
        iss: str,
        auth_login_url: str,
        auth_token_url: str,
        jwks_url: str,
        private_key: Optional[str] = None,
        public_key: Optional[str] = None,
    ):
        self.platform_id = platform_id
        self.client_id = client_id
        self.deployment_id = deployment_id
        self.iss = iss
        self.auth_login_url = auth_login_url
        self.auth_token_url = auth_token_url
        self.jwks_url = jwks_url
        self.private_key = private_key
        self.public_key = public_key
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "platform_id": self.platform_id,
            "client_id": self.client_id,
            "deployment_id": self.deployment_id,
            "iss": self.iss,
            "auth_login_url": self.auth_login_url,
            "auth_token_url": self.auth_token_url,
            "jwks_url": self.jwks_url,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LTIPlatformConfig":
        return cls(
            platform_id=data.get("platform_id", ""),
            client_id=data.get("client_id", ""),
            deployment_id=data.get("deployment_id", ""),
            iss=data.get("iss", ""),
            auth_login_url=data.get("auth_login_url", ""),
            auth_token_url=data.get("auth_token_url", ""),
            jwks_url=data.get("jwks_url", ""),
            private_key=data.get("private_key"),
            public_key=data.get("public_key"),
        )


class LTILaunchData:
    """Parsed LTI 1.3 launch data."""
    
    def __init__(self, claims: Dict[str, Any]):
        self.claims = claims
        self._parse_claims()
    
    def _parse_claims(self):
        """Extract commonly used data from claims."""
        # Standard OIDC claims
        self.issuer = self.claims.get(CLAIM_ISS, "")
        self.subject = self.claims.get(CLAIM_SUB, "")  # User ID in platform
        self.audience = self.claims.get(CLAIM_AUD, "")
        
        # User info
        self.name = self.claims.get(CLAIM_NAME, "")
        self.given_name = self.claims.get(CLAIM_GIVEN_NAME, "")
        self.family_name = self.claims.get(CLAIM_FAMILY_NAME, "")
        self.email = self.claims.get(CLAIM_EMAIL, "")
        
        # LTI specific
        self.message_type = self.claims.get(CLAIM_MESSAGE_TYPE, "")
        self.version = self.claims.get(CLAIM_VERSION, "")
        self.deployment_id = self.claims.get(CLAIM_DEPLOYMENT_ID, "")
        self.target_link_uri = self.claims.get(CLAIM_TARGET_LINK_URI, "")
        
        # Roles
        self.roles = self.claims.get(CLAIM_ROLES, [])
        
        # Context (course info)
        context = self.claims.get(CLAIM_CONTEXT, {})
        self.context_id = context.get("id", "")
        self.context_label = context.get("label", "")
        self.context_title = context.get("title", "")
        self.context_type = context.get("type", [])
        
        # Resource link (activity info)
        resource_link = self.claims.get(CLAIM_RESOURCE_LINK, {})
        self.resource_link_id = resource_link.get("id", "")
        self.resource_link_title = resource_link.get("title", "")
        self.resource_link_description = resource_link.get("description", "")
        
        # Launch presentation
        presentation = self.claims.get(CLAIM_LAUNCH_PRESENTATION, {})
        self.return_url = presentation.get("return_url", "")
        self.document_target = presentation.get("document_target", "iframe")
        self.locale = presentation.get("locale", "en")
        
        # Custom parameters
        self.custom = self.claims.get(CLAIM_CUSTOM, {})
        
        # Deep linking settings (for deep linking requests)
        self.deep_linking_settings = self.claims.get(CLAIM_DEEP_LINKING_SETTINGS, {})
    
    @property
    def user_id(self) -> str:
        """Get a unique user identifier."""
        return self.subject or self.email or ""
    
    @property
    def display_name(self) -> str:
        """Get user's display name."""
        if self.name:
            return self.name
        parts = [self.given_name, self.family_name]
        name = " ".join(p for p in parts if p)
        return name or self.email or self.subject
    
    @property
    def is_instructor(self) -> bool:
        """Check if user has instructor role."""
        return any(ROLE_INSTRUCTOR in role for role in self.roles)
    
    @property
    def is_learner(self) -> bool:
        """Check if user has learner/student role."""
        return any(ROLE_LEARNER in role for role in self.roles)
    
    @property
    def is_admin(self) -> bool:
        """Check if user has admin role."""
        return any(ROLE_ADMIN in role for role in self.roles)
    
    @property
    def course_id(self) -> str:
        """Get course identifier."""
        return self.context_id
    
    @property
    def course_name(self) -> str:
        """Get course name."""
        return self.context_title or self.context_label
    
    @property
    def lab_id(self) -> str:
        """Get lab/activity identifier from custom params or resource link."""
        return self.custom.get("lab_id", self.resource_link_id)
    
    @property
    def lab_type(self) -> str:
        """Get lab type from custom params."""
        return self.custom.get("lab_type", "attackbox")
    
    def to_session_request(self) -> Dict[str, Any]:
        """Convert to session creation request format."""
        return {
            "student_id": self.user_id,
            "student_name": self.display_name,
            "student_email": self.email,
            "course_id": self.course_id,
            "course_name": self.course_name,
            "lab_id": self.lab_id,
            "lab_type": self.lab_type,
            "is_instructor": self.is_instructor,
            "metadata": {
                "lti_version": self.version,
                "deployment_id": self.deployment_id,
                "resource_link_id": self.resource_link_id,
                "resource_link_title": self.resource_link_title,
                "return_url": self.return_url,
                "locale": self.locale,
                "platform_issuer": self.issuer,
            }
        }


class JWTDecoder:
    """
    Simple JWT decoder for LTI 1.3.
    
    Note: In production, use a proper JWT library like PyJWT.
    This implementation handles the basics for Lambda without external dependencies.
    """
    
    @staticmethod
    def base64url_decode(data: str) -> bytes:
        """Decode base64url encoded string."""
        # Add padding if needed
        padding = 4 - len(data) % 4
        if padding != 4:
            data += "=" * padding
        # Replace URL-safe chars
        data = data.replace("-", "+").replace("_", "/")
        return base64.b64decode(data)
    
    @staticmethod
    def base64url_encode(data: bytes) -> str:
        """Encode bytes as base64url string."""
        encoded = base64.b64encode(data).decode("utf-8")
        return encoded.replace("+", "-").replace("/", "_").rstrip("=")
    
    @classmethod
    def decode_without_verification(cls, token: str) -> Tuple[Dict, Dict, str]:
        """
        Decode a JWT without verifying the signature.
        Returns (header, payload, signature).
        
        WARNING: Only use for testing or when signature verification is done separately.
        """
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError("Invalid JWT format")
        
        header = json.loads(cls.base64url_decode(parts[0]))
        payload = json.loads(cls.base64url_decode(parts[1]))
        signature = parts[2]
        
        return header, payload, signature
    
    @classmethod
    def decode_header(cls, token: str) -> Dict[str, Any]:
        """Decode just the JWT header."""
        parts = token.split(".")
        if len(parts) < 1:
            raise ValueError("Invalid JWT format")
        return json.loads(cls.base64url_decode(parts[0]))


class LTIJWKSProvider:
    """
    Provides JWKS (JSON Web Key Set) for the tool.
    
    In production, you'd want to:
    1. Store keys in AWS Secrets Manager or KMS
    2. Support key rotation
    3. Cache platform JWKS
    """
    
    def __init__(self, kid: str = "cyberlab-lti-key"):
        self.kid = kid
        self._private_key = None
        self._public_key = None
    
    def get_jwks(self) -> Dict[str, Any]:
        """
        Get the public JWKS for this tool.
        Platforms use this to verify our signatures (for Deep Linking responses).
        """
        # In production, load actual RSA public key
        # For now, return a placeholder structure
        return {
            "keys": [
                {
                    "kty": "RSA",
                    "kid": self.kid,
                    "use": "sig",
                    "alg": "RS256",
                    "n": "",  # RSA modulus (base64url)
                    "e": "AQAB",  # RSA exponent
                }
            ]
        }
    
    def generate_key_pair(self) -> Tuple[str, str]:
        """
        Generate an RSA key pair for signing.
        
        Returns:
            Tuple of (private_key_pem, public_key_pem)
        """
        # This would use cryptography library in production
        # For Lambda, consider using AWS KMS for key management
        raise NotImplementedError("Use AWS KMS or Secrets Manager for key management")


class LTINonceStore:
    """
    Nonce storage for replay attack prevention.
    Uses DynamoDB for persistence.
    """
    
    def __init__(self, table_name: str):
        import boto3
        self.dynamodb = boto3.resource("dynamodb")
        self.table = self.dynamodb.Table(table_name)
    
    def check_and_store(self, nonce: str, issuer: str, expires_in: int = 600) -> bool:
        """
        Check if nonce exists, if not store it.
        Returns True if nonce is new (valid), False if replay.
        """
        import time
        from botocore.exceptions import ClientError
        
        now = int(time.time())
        nonce_key = f"{issuer}:{nonce}"
        
        try:
            # Try to add the nonce with condition that it doesn't exist
            self.table.put_item(
                Item={
                    "nonce_key": nonce_key,
                    "created_at": now,
                    "expires_at": now + expires_in,
                },
                ConditionExpression="attribute_not_exists(nonce_key)"
            )
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                logger.warning(f"Replay attack detected: nonce {nonce} already used")
                return False
            raise


class LTIStateStore:
    """
    State storage for OIDC login flow.
    Stores state between login initiation and callback.
    """
    
    def __init__(self, table_name: str):
        import boto3
        self.dynamodb = boto3.resource("dynamodb")
        self.table = self.dynamodb.Table(table_name)
    
    def store_state(self, state: str, data: Dict[str, Any], ttl: int = 600) -> bool:
        """Store state data for OIDC flow."""
        import time
        from botocore.exceptions import ClientError
        
        try:
            self.table.put_item(
                Item={
                    "state": state,
                    "data": data,
                    "created_at": int(time.time()),
                    "expires_at": int(time.time()) + ttl,
                }
            )
            return True
        except ClientError as e:
            logger.error(f"Failed to store state: {e}")
            return False
    
    def get_and_delete_state(self, state: str) -> Optional[Dict[str, Any]]:
        """Retrieve and delete state data."""
        from botocore.exceptions import ClientError
        
        try:
            response = self.table.get_item(Key={"state": state})
            item = response.get("Item")
            
            if item:
                # Delete after retrieval (one-time use)
                self.table.delete_item(Key={"state": state})
                return item.get("data")
            return None
        except ClientError as e:
            logger.error(f"Failed to get state: {e}")
            return None


def generate_state() -> str:
    """Generate a random state value for OIDC flow."""
    return uuid.uuid4().hex


def generate_nonce() -> str:
    """Generate a random nonce for JWT validation."""
    return uuid.uuid4().hex


def build_oidc_login_response(
    platform_config: LTIPlatformConfig,
    login_hint: str,
    lti_message_hint: Optional[str],
    target_link_uri: str,
    state: str,
    nonce: str,
    redirect_uri: str,
) -> str:
    """
    Build the OIDC login redirect URL.
    
    This is step 2 of the LTI 1.3 flow:
    1. Platform initiates login to tool
    2. Tool redirects to platform auth endpoint (this function)
    3. Platform authenticates and redirects back with id_token
    """
    params = {
        "response_type": "id_token",
        "response_mode": "form_post",
        "scope": "openid",
        "client_id": platform_config.client_id,
        "redirect_uri": redirect_uri,
        "login_hint": login_hint,
        "state": state,
        "nonce": nonce,
        "prompt": "none",  # No additional prompts
    }
    
    if lti_message_hint:
        params["lti_message_hint"] = lti_message_hint
    
    return f"{platform_config.auth_login_url}?{urlencode(params)}"


def validate_id_token_claims(claims: Dict[str, Any], expected_nonce: str, 
                              client_id: str, deployment_id: Optional[str] = None) -> Tuple[bool, str]:
    """
    Validate the claims in an LTI 1.3 id_token.
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Check expiration
    exp = claims.get(CLAIM_EXP, 0)
    if exp < time.time():
        return False, "Token has expired"
    
    # Check issued at (not in the future)
    iat = claims.get(CLAIM_IAT, 0)
    if iat > time.time() + 300:  # Allow 5 min clock skew
        return False, "Token issued in the future"
    
    # Check nonce
    if claims.get(CLAIM_NONCE) != expected_nonce:
        return False, "Invalid nonce"
    
    # Check audience (client_id)
    aud = claims.get(CLAIM_AUD)
    if isinstance(aud, list):
        if client_id not in aud:
            return False, "Invalid audience"
        # If aud is array, azp must be present and match client_id
        if claims.get(CLAIM_AZP) != client_id:
            return False, "Invalid authorized party"
    elif aud != client_id:
        return False, "Invalid audience"
    
    # Check deployment_id if provided
    if deployment_id and claims.get(CLAIM_DEPLOYMENT_ID) != deployment_id:
        return False, "Invalid deployment ID"
    
    # Check LTI version
    if claims.get(CLAIM_VERSION) != LTI_VERSION:
        return False, f"Unsupported LTI version: {claims.get(CLAIM_VERSION)}"
    
    # Check message type
    message_type = claims.get(CLAIM_MESSAGE_TYPE)
    if message_type not in [LTI_MESSAGE_TYPE, LTI_DEEP_LINKING_MESSAGE_TYPE]:
        return False, f"Unsupported message type: {message_type}"
    
    return True, ""


def create_deep_linking_response_jwt(
    platform_config: LTIPlatformConfig,
    deployment_id: str,
    data: str,
    content_items: List[Dict[str, Any]],
    private_key: str,
) -> str:
    """
    Create a signed JWT for Deep Linking response.
    
    This would require a proper JWT library (PyJWT) with RS256 support.
    In Lambda, consider using a Lambda Layer with PyJWT.
    """
    raise NotImplementedError("Requires PyJWT library for RS256 signing")


# HTML Templates for LTI responses

LAUNCH_PAGE_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberLab - {lab_title}</title>
    <script>
        // Break out of iframe - open in new full-screen tab
        if (window.self !== window.top) {{
            // We're in an iframe, open in new tab
            window.top.location.href = window.location.href;
        }}
    </script>
    <style>
        :root {{
            --primary: #0ea5e9;
            --primary-dark: #0284c7;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --cyber-green: #22c55e;
            --cyber-purple: #8b5cf6;
            --bg-dark: #0f172a;
            --bg-card: #1e293b;
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --border: #334155;
        }}
        
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        
        body {{
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, var(--bg-dark) 0%, #1a1a2e 100%);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }}
        
        .container {{ max-width: 650px; width: 100%; }}
        
        .card {{
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            position: relative;
            overflow: hidden;
        }}
        
        /* Animated border for loading state */
        .card.loading::before {{
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--cyber-green), var(--cyber-purple), var(--primary), var(--cyber-green));
            background-size: 300% 100%;
            animation: borderFlow 2s linear infinite;
        }}
        
        @keyframes borderFlow {{
            0% {{ background-position: 0% 50%; }}
            100% {{ background-position: 100% 50%; }}
        }}
        
        .header {{ text-align: center; margin-bottom: 24px; }}
        
        .logo {{
            width: 80px; height: 80px;
            background: linear-gradient(135deg, var(--primary), var(--cyber-purple));
            border-radius: 20px;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 16px;
            font-size: 40px;
            animation: logoPulse 2s ease-in-out infinite;
        }}
        
        .loading .logo {{ animation: logoSpin 3s linear infinite; }}
        
        @keyframes logoPulse {{
            0%, 100% {{ transform: scale(1); }}
            50% {{ transform: scale(1.05); }}
        }}
        
        @keyframes logoSpin {{
            0% {{ transform: rotateY(0deg); }}
            100% {{ transform: rotateY(360deg); }}
        }}
        
        h1 {{ font-size: 24px; margin-bottom: 4px; }}
        .subtitle {{ color: var(--text-secondary); font-size: 14px; }}
        
        /* Loading Section */
        .loading-section {{
            margin: 24px 0;
            padding: 24px;
            background: rgba(0,0,0,0.3);
            border-radius: 12px;
            border: 1px solid var(--border);
        }}
        
        .progress-container {{ margin-bottom: 20px; }}
        
        .progress-header {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
        }}
        
        .progress-percent {{
            font-family: 'Courier New', monospace;
            color: var(--cyber-green);
            font-weight: bold;
        }}
        
        .progress-bar {{
            height: 8px;
            background: rgba(0,0,0,0.4);
            border-radius: 4px;
            overflow: hidden;
        }}
        
        .progress-fill {{
            height: 100%;
            background: linear-gradient(90deg, var(--cyber-green), var(--primary));
            border-radius: 4px;
            transition: width 0.5s ease-out;
            position: relative;
        }}
        
        .progress-fill::after {{
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 1.5s infinite;
        }}
        
        @keyframes shimmer {{
            0% {{ transform: translateX(-100%); }}
            100% {{ transform: translateX(100%); }}
        }}
        
        .status-message {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            background: rgba(34, 197, 94, 0.1);
            border: 1px solid rgba(34, 197, 94, 0.3);
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            color: var(--cyber-green);
            margin-bottom: 16px;
        }}
        
        .status-icon {{ font-size: 18px; }}
        
        .terminal-cursor {{
            display: inline-block;
            width: 8px;
            height: 16px;
            background: var(--cyber-green);
            animation: blink 1s step-end infinite;
            vertical-align: middle;
            margin-left: 4px;
        }}
        
        @keyframes blink {{
            0%, 50% {{ opacity: 1; }}
            51%, 100% {{ opacity: 0; }}
        }}
        
        .fact-box {{
            padding: 16px;
            background: rgba(139, 92, 246, 0.1);
            border: 1px solid rgba(139, 92, 246, 0.3);
            border-radius: 8px;
            text-align: center;
        }}
        
        .fact-label {{
            font-size: 12px;
            color: var(--cyber-purple);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .fact-text {{
            font-size: 14px;
            color: var(--text-primary);
            line-height: 1.5;
        }}
        
        .fact-text em {{
            color: var(--cyber-purple);
            font-style: normal;
            font-weight: 600;
        }}
        
        /* Ready Section */
        .ready-section {{ display: none; }}
        .ready-section.show {{ display: block; }}
        .loading-section.hide {{ display: none; }}
        
        .info-grid {{ display: grid; gap: 12px; margin-bottom: 24px; }}
        
        .info-item {{
            display: flex;
            justify-content: space-between;
            padding: 12px 16px;
            background: rgba(0,0,0,0.2);
            border-radius: 8px;
        }}
        
        .info-label {{ color: var(--text-secondary); }}
        .info-value {{ font-weight: 500; }}
        
        .status {{
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 16px;
            border-radius: 12px;
            margin-bottom: 24px;
        }}
        
        .status.ready {{
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid var(--success);
        }}
        
        .status-dot {{
            width: 12px; height: 12px;
            border-radius: 50%;
            background: var(--success);
            animation: pulse 2s infinite;
        }}
        
        @keyframes pulse {{
            0%, 100% {{ opacity: 1; transform: scale(1); }}
            50% {{ opacity: 0.7; transform: scale(1.1); }}
        }}
        
        .actions {{ display: flex; flex-direction: column; gap: 12px; }}
        
        .btn {{
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 16px 24px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
        }}
        
        .btn-primary {{
            background: linear-gradient(135deg, var(--success), var(--primary));
            color: white;
            font-size: 18px;
        }}
        
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 10px 30px -10px rgba(34, 197, 94, 0.5);
        }}
        
        .btn-secondary {{
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-secondary);
        }}
        
        .btn-secondary:hover {{
            border-color: var(--primary);
            color: var(--primary);
        }}
        
        .timer {{
            text-align: center;
            margin-top: 24px;
            padding-top: 24px;
            border-top: 1px solid var(--border);
        }}
        
        .timer-value {{
            font-size: 32px;
            font-family: 'Courier New', monospace;
            color: var(--primary);
        }}
        
        .timer-label {{
            color: var(--text-secondary);
            font-size: 12px;
            margin-top: 4px;
        }}
        
        .footer {{
            text-align: center;
            margin-top: 24px;
            color: var(--text-secondary);
            font-size: 12px;
        }}
        
        .auto-redirect-notice {{
            text-align: center;
            margin-top: 16px;
            padding: 12px;
            background: rgba(14, 165, 233, 0.1);
            border-radius: 8px;
            font-size: 13px;
            color: var(--primary);
        }}
        
        .spinner {{
            width: 20px; height: 20px;
            border: 2px solid transparent;
            border-top-color: currentColor;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }}
        
        @keyframes spin {{ to {{ transform: rotate(360deg); }} }}
        
        .hidden {{ display: none; }}
        
        /* Mobile responsive */
        @media (max-width: 480px) {{
            .card {{ padding: 20px; }}
            h1 {{ font-size: 20px; }}
            .btn {{ padding: 14px 20px; font-size: 15px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="card {card_class}" id="main-card">
            <div class="header">
                <div class="logo">🐉</div>
                <h1>{lab_title}</h1>
                <p class="subtitle">{course_name}</p>
            </div>
            
            <!-- Loading State -->
            <div class="loading-section" id="loading-section">
                <div class="progress-container">
                    <div class="progress-header">
                        <span>Initializing AttackBox</span>
                        <span class="progress-percent" id="progress-percent">0%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="progress-fill" style="width: 0%"></div>
                    </div>
                </div>
                
                <div class="status-message" id="status-message">
                    <span class="status-icon">⚡</span>
                    <span id="status-text">Connecting to CyberLab infrastructure...</span>
                    <span class="terminal-cursor"></span>
                </div>
                
                <div class="fact-box">
                    <div class="fact-label">💡 Did You Know?</div>
                    <div class="fact-text" id="fact-text">Loading cyber facts...</div>
                </div>
                
                <div class="auto-redirect-notice" id="redirect-notice" style="display: none;">
                    🚀 AttackBox ready! Launching in <span id="countdown">5</span> seconds...
                </div>
            </div>
            
            <!-- Ready State -->
            <div class="ready-section" id="ready-section">
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">Student</span>
                        <span class="info-value">{student_name}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Session ID</span>
                        <span class="info-value">{session_id}</span>
                    </div>
                </div>
                
                <div class="status ready">
                    <div class="status-dot"></div>
                    <span>AttackBox Ready</span>
                </div>
                
                <div class="actions">
                    <a href="{guacamole_url}" target="_blank" class="btn btn-primary" id="launch-btn">
                        <span>🚀</span>
                        <span>Open AttackBox</span>
                    </a>
                    <button class="btn btn-secondary" id="terminate-btn" onclick="terminateSession()">
                        <span>⏹️</span>
                        <span>End Session</span>
                    </button>
                </div>
                
                <div class="timer">
                    <div class="timer-value" id="timer">--:--:--</div>
                    <div class="timer-label">Time Remaining</div>
                </div>
            </div>
        </div>
        
        <div class="footer">
            CyberLab • Secure Lab Environment
        </div>
    </div>
    
    <script>
        const sessionData = {session_data_json};
        const guacamoleUrl = "{guacamole_url}";
        const apiBaseUrl = "{api_base_url}";
        
        // Cyber facts and trivia
        const cyberFacts = [
            {{ text: '<em>Netcat</em> is called the "Swiss Army knife" of networking tools.', icon: '🔧' }},
            {{ text: 'The first computer virus, <em>Creeper</em>, was created in 1971.', icon: '🦠' }},
            {{ text: '<em>Kali Linux</em> contains over 600 penetration testing tools.', icon: '🐉' }},
            {{ text: 'The term <em>hacker</em> originally meant a skilled programmer.', icon: '👨‍💻' }},
            {{ text: '<em>Metasploit</em> was created by HD Moore in 2003.', icon: '💉' }},
            {{ text: 'The average cost of a data breach is <em>$4.45 million</em>.', icon: '💰' }},
            {{ text: '<em>Nmap</em> was first released in 1997 by Gordon Lyon.', icon: '🗺️' }},
            {{ text: '<em>SQL injection</em> remains in the OWASP Top 10 since 2010.', icon: '💾' }},
            {{ text: 'The first <em>ransomware</em> appeared in 1989 (AIDS Trojan).', icon: '🔐' }},
            {{ text: '<em>Burp Suite</em> is the most popular web security testing tool.', icon: '🕷️' }},
            {{ text: '<em>John the Ripper</em> can crack over 200 hash types.', icon: '🔓' }},
            {{ text: 'The <em>Morris Worm</em> (1988) infected ~6,000 computers.', icon: '🐛' }},
            {{ text: '<em>Wireshark</em> was originally called Ethereal.', icon: '🦈' }},
            {{ text: 'The term <em>phishing</em> first appeared around 1996.', icon: '🎣' }},
            {{ text: '<em>Zero-day</em> exploits sell for up to $2.5 million.', icon: '💎' }},
        ];
        
        // Progress messages (cyber-ops style)
        const progressMessages = [
            {{ pct: 5, msg: "Establishing secure tunnel...", icon: "🔒" }},
            {{ pct: 12, msg: "Authenticating with CyberLab...", icon: "🔑" }},
            {{ pct: 20, msg: "Allocating AttackBox instance...", icon: "📦" }},
            {{ pct: 28, msg: "Initializing Kali Linux environment...", icon: "🐉" }},
            {{ pct: 35, msg: "Loading penetration testing toolkit...", icon: "🧰" }},
            {{ pct: 45, msg: "Configuring network interfaces...", icon: "🌐" }},
            {{ pct: 52, msg: "Mounting secure storage volumes...", icon: "💾" }},
            {{ pct: 60, msg: "Starting desktop environment...", icon: "🖥️" }},
            {{ pct: 68, msg: "Preparing red-team engagement modules...", icon: "⚔️" }},
            {{ pct: 75, msg: "Initializing RDP connection...", icon: "📡" }},
            {{ pct: 82, msg: "Applying security configurations...", icon: "🛡️" }},
            {{ pct: 88, msg: "Running final system checks...", icon: "✅" }},
            {{ pct: 95, msg: "AttackBox nearly ready...", icon: "🚀" }},
            {{ pct: 100, msg: "AttackBox initialized successfully!", icon: "✨" }},
        ];
        
        let currentProgress = 0;
        let currentFactIndex = 0;
        let isReady = sessionData.status === 'ready' || sessionData.status === 'active';
        let statusCheckInterval;
        let progressInterval;
        let factInterval;
        
        // Initialize
        function init() {{
            if (isReady) {{
                showReadyState();
            }} else {{
                startLoadingAnimation();
                startStatusPolling();
            }}
            updateTimer();
            setInterval(updateTimer, 1000);
        }}
        
        function startLoadingAnimation() {{
            document.getElementById('main-card').classList.add('loading');
            
            // Progress animation (simulated + real status)
            progressInterval = setInterval(() => {{
                if (currentProgress < 90 && !isReady) {{
                    // Simulate progress up to 90%
                    const increment = Math.random() * 3 + 1;
                    currentProgress = Math.min(90, currentProgress + increment);
                    updateProgress(currentProgress);
                }}
            }}, 800);
            
            // Rotate facts every 5 seconds
            updateFact();
            factInterval = setInterval(updateFact, 5000);
        }}
        
        function updateProgress(pct) {{
            const percent = Math.round(pct);
            document.getElementById('progress-percent').textContent = percent + '%';
            document.getElementById('progress-fill').style.width = percent + '%';
            
            // Update status message based on progress
            for (let i = progressMessages.length - 1; i >= 0; i--) {{
                if (percent >= progressMessages[i].pct) {{
                    const msg = progressMessages[i];
                    document.getElementById('status-text').textContent = msg.msg;
                    document.querySelector('.status-message .status-icon').textContent = msg.icon;
                    break;
                }}
            }}
        }}
        
        function updateFact() {{
            const fact = cyberFacts[currentFactIndex];
            document.getElementById('fact-text').innerHTML = fact.text;
            currentFactIndex = (currentFactIndex + 1) % cyberFacts.length;
        }}
        
        function startStatusPolling() {{
            statusCheckInterval = setInterval(async () => {{
                try {{
                    const response = await fetch(`${{apiBaseUrl}}/sessions/${{sessionData.session_id}}`);
                    const data = await response.json();
                    
                    if (data.data && (data.data.status === 'ready' || data.data.status === 'active')) {{
                        isReady = true;
                        completeLoading();
                    }}
                }} catch (e) {{
                    console.error('Status check failed:', e);
                }}
            }}, 3000);
        }}
        
        function completeLoading() {{
            clearInterval(statusCheckInterval);
            clearInterval(progressInterval);
            
            // Animate to 100%
            currentProgress = 100;
            updateProgress(100);
            
            // Show redirect notice
            setTimeout(() => {{
                document.getElementById('redirect-notice').style.display = 'block';
                startCountdown();
            }}, 500);
        }}
        
        function startCountdown() {{
            let count = 5;
            const countdownEl = document.getElementById('countdown');
            
            const countdownInterval = setInterval(() => {{
                count--;
                countdownEl.textContent = count;
                
                if (count <= 0) {{
                    clearInterval(countdownInterval);
                    clearInterval(factInterval);
                    
                    // Open Guacamole and show ready state
                    window.open(guacamoleUrl, '_blank');
                    showReadyState();
                }}
            }}, 1000);
        }}
        
        function showReadyState() {{
            document.getElementById('main-card').classList.remove('loading');
            document.getElementById('loading-section').classList.add('hide');
            document.getElementById('ready-section').classList.add('show');
        }}
        
        function updateTimer() {{
            if (!sessionData.expires_at) return;
            
            const now = Math.floor(Date.now() / 1000);
            const remaining = sessionData.expires_at - now;
            
            if (remaining <= 0) {{
                document.getElementById('timer').textContent = 'EXPIRED';
                return;
            }}
            
            const hours = Math.floor(remaining / 3600);
            const minutes = Math.floor((remaining % 3600) / 60);
            const seconds = remaining % 60;
            
            document.getElementById('timer').textContent = 
                `${{String(hours).padStart(2, '0')}}:${{String(minutes).padStart(2, '0')}}:${{String(seconds).padStart(2, '0')}}`;
        }}
        
        async function terminateSession() {{
            if (!confirm('End your lab session? All unsaved work will be lost.')) return;
            
            const btn = document.getElementById('terminate-btn');
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner"></div><span>Ending...</span>';
            
            try {{
                await fetch(`${{apiBaseUrl}}/sessions/${{sessionData.session_id}}`, {{
                    method: 'DELETE'
                }});
                
                if (sessionData.return_url) {{
                    window.location.href = sessionData.return_url;
                }} else {{
                    alert('Session ended. You can close this window.');
                }}
            }} catch (e) {{
                console.error('Terminate failed:', e);
                btn.disabled = false;
                btn.innerHTML = '<span>⏹️</span><span>End Session</span>';
                alert('Failed to end session. Please try again.');
            }}
        }}
        
        // Start everything
        init();
    </script>
</body>
</html>
"""

ERROR_PAGE_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberLab - Error</title>
    <style>
        body {{
            font-family: 'Segoe UI', system-ui, sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1a1a2e 100%);
            color: #f1f5f9;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            margin: 0;
        }}
        .error-card {{
            background: #1e293b;
            border: 1px solid #ef4444;
            border-radius: 16px;
            padding: 32px;
            max-width: 500px;
            text-align: center;
        }}
        .error-icon {{ font-size: 48px; margin-bottom: 16px; }}
        h1 {{ color: #ef4444; margin-bottom: 16px; }}
        p {{ color: #94a3b8; margin-bottom: 24px; }}
        .btn {{
            display: inline-block;
            padding: 12px 24px;
            background: #334155;
            color: #f1f5f9;
            text-decoration: none;
            border-radius: 8px;
        }}
        .btn:hover {{ background: #475569; }}
    </style>
</head>
<body>
    <div class="error-card">
        <div class="error-icon">⚠️</div>
        <h1>{error_title}</h1>
        <p>{error_message}</p>
        <a href="{return_url}" class="btn">Return to Course</a>
    </div>
</body>
</html>
"""


def render_launch_page(
    session_data: Dict[str, Any],
    launch_data: LTILaunchData,
    guacamole_url: str,
    api_base_url: str,
) -> str:
    """Render the launch page HTML with loading animation and cyber facts."""
    from decimal import Decimal
    
    status = session_data.get("status", "pending")
    is_ready = status in ["ready", "active"]
    
    # Card class for loading animation
    card_class = "" if is_ready else "loading"
    
    # Handle Decimal types from DynamoDB
    expires_at = session_data.get("expires_at")
    if isinstance(expires_at, Decimal):
        expires_at = int(expires_at)
    
    # Custom JSON encoder for Decimal
    class DecimalEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, Decimal):
                return int(obj) if obj % 1 == 0 else float(obj)
            return super().default(obj)
    
    return LAUNCH_PAGE_TEMPLATE.format(
        lab_title=launch_data.resource_link_title or "AttackBox Lab",
        course_name=launch_data.course_name or "CyberLab",
        student_name=launch_data.display_name,
        session_id=session_data.get("session_id", ""),
        card_class=card_class,
        guacamole_url=guacamole_url,
        session_data_json=json.dumps({
            "session_id": session_data.get("session_id"),
            "status": status,
            "expires_at": expires_at,
            "return_url": launch_data.return_url,
        }, cls=DecimalEncoder),
        api_base_url=api_base_url,
    )


def render_error_page(title: str, message: str, return_url: str = "") -> str:
    """Render an error page HTML."""
    return ERROR_PAGE_TEMPLATE.format(
        error_title=title,
        error_message=message,
        return_url=return_url or "#",
    )

